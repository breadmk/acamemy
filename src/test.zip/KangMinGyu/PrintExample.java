package test.KangMinGyu;

public class PrintExample {
	
	public static void main (String[] args) {
		Printer myPrint = new Printer();
		
		myPrint.println(10);
		myPrint.println(true);
		myPrint.println(5.7);
		myPrint.println("ȫ�浿");
	}

}
